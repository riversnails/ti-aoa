UNPI
====

SerialNode
----------

A class that reads from serial in a thread, and invokes a
designated parser to check if the input stream contains a
serial frame.


UNPIParser
----------

Parser for the uNPI subsystem.

